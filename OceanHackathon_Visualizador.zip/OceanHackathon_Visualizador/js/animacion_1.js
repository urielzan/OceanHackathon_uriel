L.TimeDimension.Layer.GeoJson.GeometryCollection = L.TimeDimension.Layer.GeoJson.extend({

    // Do not modify features. Just return the feature if it intersects
    // the time interval    
    _getFeatureBetweenDates: function(feature, minTime, maxTime) {
        var featureStringTimes = this._getFeatureTimes(feature);
        if (featureStringTimes.length == 0) {
            return feature;
        }
        var featureTimes = [];
        for (var i = 0, l = featureStringTimes.length; i < l; i++) {
            var time = featureStringTimes[i]
            if (typeof time == 'string' || time instanceof String) {
                time = Date.parse(time.trim());
            }
            featureTimes.push(time);
        }

        if (featureTimes[0] > maxTime || featureTimes[l - 1] < minTime) {
            return null;
        }
        return feature;
    },

});

L.timeDimension.layer.geoJson.geometryCollection = function(layer, options) {
    return new L.TimeDimension.Layer.GeoJson.GeometryCollection(layer, options);
};


function getCommonBaseLayers(map){
    var osmLayer = L.tileLayer('http://{s}.tile.osm.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors'
    });
    var bathymetryLayer = L.tileLayer.wms("http://ows.emodnet-bathymetry.eu/wms", {
        layers: 'emodnet:mean_atlas_land',
        format: 'image/png',
        transparent: true,
        attribution: "EMODnet Bathymetry",
        opacity: 0.8
    });
    var coastlinesLayer = L.tileLayer.wms("http://ows.emodnet-bathymetry.eu/wms", {
        layers: 'coastlines',
        format: 'image/png',
        transparent: true,
        attribution: "EMODnet Bathymetry",
        opacity: 0.8
    });
    var bathymetryGroupLayer = L.layerGroup([bathymetryLayer, coastlinesLayer]);    
    bathymetryGroupLayer.addTo(map);
    return {
        "EMODnet Bathymetry": bathymetryGroupLayer,
        "OSM": osmLayer
    };
}

var map = L.map('map', {
    zoom: 5,
    fullscreenControl: true,
    timeDimensionControl: true,
    timeDimensionControlOptions: {
        loopButton: true,
        autoPlay: true,
        playerOptions: {
            transitionTime: 1000,
            loop: true,
        }
    },
    timeDimension: true,
    center: [21.1, -86.9]
});
var baseLayers = getCommonBaseLayers(map); // see baselayers.js
L.control.layers(baseLayers, {}).addTo(map);

var geoJsonLayer = L.geoJson(geoJsonFeatures, {
  style: function(feature) {    
    return {
      "color": "#FF0000",
      "weight": 2,
      "opacity": 0.4
    };
  },
  onEachFeature: function(feature, layer) {
        console.log(feature.properties);
        content = "<b>Time:</b> " + feature.properties.time + "<br><b>Area:</b> " + feature.properties.area;
        layer.bindPopup(content);
      }
});

map.fitBounds(geoJsonLayer.getBounds());

var geoJsonTimeLayer = L.timeDimension.layer.geoJson.geometryCollection(geoJsonLayer, {
  updateTimeDimension: true,
  updateTimeDimensionMode: 'replace', 
  duration: 'PT40M',
});
geoJsonTimeLayer.addTo(map);